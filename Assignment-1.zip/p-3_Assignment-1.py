def kidsWithCandies(candies, extraCandies):
    max_ele = max(candies)
    return [(i+extraCandies)>=max_ele for i in candies]

print(kidsWithCandies([2,3,5,1,3],3))
