def running_sum(arr):
    for i in range(1,len(n)):
        arr[i] = arr[i] + arr[i-1]
    return arr

if __name__==__'main__':
    k  = [1,2,3,4]
    print(running_sum(k))
