def shuffle_array(arr,n):
    req = []
    for i in range(n):
        req.append(arr[i])
        req.append(arr[n+i])
    return req

print(shuffle_array([2,5,1,3,4,7],3))
